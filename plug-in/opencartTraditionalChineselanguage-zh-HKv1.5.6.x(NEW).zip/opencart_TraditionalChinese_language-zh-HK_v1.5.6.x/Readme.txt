繁體中文語言包 OpenCart V 1.5.6.x

下載解壓後有兩個文件夾，admin目錄下的語言翻譯是後台用的，catalog目錄下的語言翻譯是前台用的。

-------------------------------------------------------------------------------------------------------------
Name: 	Traditional Chinese Language Pack
Exension Type: 	Languages
License: 	    Free
Author: 	    OpenCart.cn
Date Added: 	2014/05/28
Version 	Compatible With v1.5.6.x
-------------------------------------------------------------------------------------------------------------

1、商店後台登入：

選擇： System -> Localisation -> Languages -> Insert

填入如下：

Language Name: 繁體中文

Code = zh_HK
Locale = zh_HK.UTF-8,zh_HK,zh-hk,hongkong
Image = hk.png
Directory = zh-HK
Filename = zh-HK
Status: Enabled (啟動)
Sort Order: 任意數字

填寫後按 Save 存檔

2、把繁體中文設置為預設語言：

選擇：Sytem -> Settings -> Local

在下列項目 選擇繁體中文

Language: 繁體中文
Administration Language: 繁體中文

填寫後按 Save 存檔



==================================
opencart中文支持網www.opencart.cn
==================================