<?php
// Text
$_['text_information']  = '關於我們';
$_['text_service']      = '客戶服務';
$_['text_extra']        = '其他';
$_['text_contact']      = '聯繫我們';
$_['text_return']       = '退換服務';
$_['text_sitemap']      = '網站地圖';
$_['text_manufacturer'] = '品牌專區';
$_['text_voucher']      = '禮&nbsp;品&nbsp;券';
$_['text_affiliate']    = '加盟會員';
$_['text_special']      = '特別優惠';
$_['text_account']      = '會員中心';
$_['text_order']        = '歷史訂單';
$_['text_wishlist']     = '收藏列表';
$_['text_newsletter']   = '訂閱咨詢';
$_['text_powered']      = '技術支持 <a href="http://www.opencart.cn">OpenCart中文支持網</a><br /> %s &copy; %s';
?>