<?php
// Text
$_['text_home']     = '首頁';
$_['text_wishlist'] = '收藏（%s）';
$_['text_shopping_cart']     = '購物車';
$_['text_search']   = '搜索';
$_['text_welcome']  = '歡迎光臨，您可以<a href="%s">登錄</a> 或 <a href="%s">註冊一個帳戶</a>。';
$_['text_logged']   = '您登錄為<a href="%s">%s</a> <b>(</b> <a href="%s">退出</a> <b>)</b>';
$_['text_account']  = '會員中心';
$_['text_checkout'] = '去結賬';
?>