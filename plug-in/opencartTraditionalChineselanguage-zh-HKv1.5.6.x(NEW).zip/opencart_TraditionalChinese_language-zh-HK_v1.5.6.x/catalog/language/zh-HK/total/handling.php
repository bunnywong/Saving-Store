<?php
$_['text_handling'] = '手續費';
?>