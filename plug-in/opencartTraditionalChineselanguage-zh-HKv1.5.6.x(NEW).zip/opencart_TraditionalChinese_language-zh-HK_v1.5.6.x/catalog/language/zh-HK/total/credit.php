<?php
$_['text_credit']   = '商戶信用';
$_['text_order_id'] = '訂單號： #%s';
?>