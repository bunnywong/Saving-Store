<?php
// Text
$_['text_voucher']  = '禮品券(%s)';
?>