<?php
// Text
$_['text_subject']  = '%s - 加盟申請';
$_['text_welcome']  = '感謝您加盟 %s ！';
$_['text_approval'] = '您的賬戶正在審核中。 審核通過後您可以通過如下網址使用您的郵件地址和密碼登錄我們的網站：';
$_['text_services'] = '登錄後您可以生成鏈接代碼， 以便跟蹤佣金和您的賬戶信息。';
$_['text_thanks']   = '謝謝！';
?>