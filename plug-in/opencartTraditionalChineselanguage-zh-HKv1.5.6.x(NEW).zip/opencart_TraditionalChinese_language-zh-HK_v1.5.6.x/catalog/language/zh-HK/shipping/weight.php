<?php
// Text
$_['text_title'] = '按重量計算運費';
$_['text_weight'] = '重量：'; 
?>