<?php
// Text
$_['text_title'] = '美國郵政服務';
$_['text_weight'] = '重量：';
$_['text_eta']    = '預計時間：';
?>