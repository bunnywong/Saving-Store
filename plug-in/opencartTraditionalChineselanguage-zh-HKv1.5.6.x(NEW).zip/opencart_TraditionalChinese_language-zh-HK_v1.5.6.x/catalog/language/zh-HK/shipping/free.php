<?php
// Text
$_['text_title']       = '免運費';
$_['text_description'] = '免運費';
?>