<?php
// Text
$_['text_title']       = '固定運費';
$_['text_description'] = '固定運費率';
?>