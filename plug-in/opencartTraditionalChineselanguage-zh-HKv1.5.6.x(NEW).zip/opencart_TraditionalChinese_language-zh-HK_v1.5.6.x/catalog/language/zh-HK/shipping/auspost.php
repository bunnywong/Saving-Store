<?php
// Text
$_['text_title']    = '澳大利亞郵政';
$_['text_express']  = '快遞';
$_['text_standard'] = '標準';
$_['text_eta']      = '天數';
?>