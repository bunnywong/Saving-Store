<?php
// Text
$_['text_title']       = '包裹 48';
$_['text_description'] = '包裹 48';
$_['text_weight']      = ' (重量: )'; 
$_['text_insurance']   = ' (受保險於: )';   
$_['text_time']        = ' (預計時間:  48 小時內)'; 
?>