<?php
// Text
$_['text_title']                               = '聯邦快遞';
$_['text_weight']                              = '重量：';
$_['text_eta']                                 = '估計時間：';
$_['text_europe_first_international_priority'] = '歐洲第一個國際優先';
$_['text_fedex_1_day_freight']                 = '聯邦1天貨運';
$_['text_fedex_2_day']                         = '聯邦2天';
$_['text_fedex_2_day_am']                      = '聯邦2天早上';
$_['text_fedex_2_day_freight']                 = '聯邦2天晚上';
$_['text_fedex_3_day_freight']                 = '聯邦3天晚上';
$_['text_fedex_express_saver']                 = '聯邦快遞';
$_['text_fedex_first_freight']                 = '聯邦第一跳';
$_['text_fedex_freight_economy']               = '聯邦航空經濟';
$_['text_fedex_freight_priority']              = '聯邦航空優先';
$_['text_fedex_ground']                        = '聯邦地面';
$_['text_first_overnight']                     = '第一夜';
$_['text_ground_home_delivery']                = '地面送貨上門';
$_['text_international_economy']               = '國際經濟';
$_['text_international_economy_freight']       = '國際貨運';
$_['text_international_first']                 = '國際一級';
$_['text_international_priority']              = '國際優先';
$_['text_international_priority_freight']      = '國際優先貨運';
$_['text_priority_overnight']                  = '優先過夜';
$_['text_smart_post']                          = 'Smart post';
$_['text_standard_overnight']                  = '標準過夜';
?>