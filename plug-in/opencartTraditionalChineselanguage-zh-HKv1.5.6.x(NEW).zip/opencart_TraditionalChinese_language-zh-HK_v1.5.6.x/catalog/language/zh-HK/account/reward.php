<?php
// Heading 
$_['heading_title']      = '我的獎勵積分';

// Column
$_['column_date_added']  = '獲取日期';
$_['column_description'] = '說明';
$_['column_points']      = '獎勵積分數';

// Text
$_['text_account']       = '賬戶';
$_['text_reward']        = '獎勵積分';
$_['text_total']         = '我的獎勵積分總數為：';
$_['text_empty']         = '您現在還沒有獲取過獎勵積分！';
?>