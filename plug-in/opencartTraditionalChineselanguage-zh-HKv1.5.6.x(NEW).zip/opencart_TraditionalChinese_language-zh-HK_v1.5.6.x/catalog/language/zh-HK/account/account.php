<?php
// Heading 
$_['heading_title']      = '我的賬戶';

// Text
$_['text_account']       = '我的賬戶';
$_['text_my_account']    = '我的賬戶';
$_['text_my_orders']     = '我的訂單';
$_['text_my_newsletter'] = '我的訂閱';
$_['text_edit']          = '編輯我的賬戶信息';
$_['text_password']      = '更新我的密碼';
$_['text_address']       = '更新我的地址簿';
$_['text_wishlist']      = '更新我的收藏列表';
$_['text_order']         = '查看我的歷史訂單';
$_['text_download']      = '下載商品';
$_['text_reward']        = '我的積分'; 
$_['text_return']        = '查看我的退換要求'; 
$_['text_newsletter']    = '訂閱 / 退訂咨詢';
$_['text_recurring']     = '分期付款';
$_['text_transaction']   = '我的交易'; 
?>
