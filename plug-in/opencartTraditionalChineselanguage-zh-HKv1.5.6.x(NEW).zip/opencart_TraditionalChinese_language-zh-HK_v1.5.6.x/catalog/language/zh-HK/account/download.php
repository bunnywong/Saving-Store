<?php
// Heading 
$_['heading_title']   = '下載商品';

// Text
$_['text_account']    = '我的賬戶';
$_['text_downloads']  = '下載商品';
$_['text_order']      = '訂單號：';
$_['text_date_added'] = '添加日期：';
$_['text_name']       = '名字：';
$_['text_remaining']  = '備註：';
$_['text_size']       = '規格：';
$_['text_download']   = '下載';
$_['text_empty']      = '您沒有購買過可下載的商品！';
?>