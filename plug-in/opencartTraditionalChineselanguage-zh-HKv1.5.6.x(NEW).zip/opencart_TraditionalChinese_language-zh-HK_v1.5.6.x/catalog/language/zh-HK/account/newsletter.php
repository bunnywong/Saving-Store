<?php
// Heading 
$_['heading_title']    = '訂閱本站最新動態';

// Text
$_['text_account']     = '我的賬戶';
$_['text_newsletter']  = '訂閱狀態';
$_['text_success']     = '成功： 您已更新訂閱功能！';

// Entry
$_['entry_newsletter'] = '訂閱：';
?>
