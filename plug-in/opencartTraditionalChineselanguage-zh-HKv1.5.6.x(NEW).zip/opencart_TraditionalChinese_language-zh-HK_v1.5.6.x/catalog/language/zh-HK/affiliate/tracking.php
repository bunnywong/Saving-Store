<?php
// Heading 
$_['heading_title']    = '加盟跟蹤';

// Text
$_['text_account']     = '賬戶';
$_['text_description'] = '為了確保您能得到我們發送的付款，我們需要跟蹤放置在URL跟蹤代碼鏈接給我們，您可以使用下面的工具來生成 %s 鏈接網站。';
$_['text_code']        = '<b>您的跟蹤號：</b>';
$_['text_generator']   = '<b>跟蹤鏈接生成</b><br />請輸入你要生成鏈接的商品名：';
$_['text_link']        = '<b>跟蹤鏈接：</b>';
?>