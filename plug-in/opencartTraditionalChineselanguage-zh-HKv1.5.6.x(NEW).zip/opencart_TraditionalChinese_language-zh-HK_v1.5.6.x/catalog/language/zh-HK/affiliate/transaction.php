<?php
// Heading 
$_['heading_title']      = '我的交易';

// Column
$_['column_date_added']  = '交易日期';
$_['column_description'] = '說明';
$_['column_amount']      = '合計 (%s)';

// Text
$_['text_account']       = '賬戶';
$_['text_transaction']   = '我的交易';
$_['text_balance']       = '我的交易餘額為：';
$_['text_empty']         = '您還沒有任何交易記錄！';
?>