<?php
// Heading
$_['heading_title'] = '您請求的頁面不存在！';

// Text
$_['text_error']    = '您所查詢的頁面不存在！';
?>