<?php
// Heading 
$_['heading_title'] = '信息中心';

// Text
$_['text_contact']  = '聯繫我們';
$_['text_sitemap']  = '網站地圖';
?>