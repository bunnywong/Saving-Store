<?php
// Heading 
$_['heading_title']  = '熱賣商品';

// Text
$_['text_reviews']     = '5 星內取得 %s 星！';
?>