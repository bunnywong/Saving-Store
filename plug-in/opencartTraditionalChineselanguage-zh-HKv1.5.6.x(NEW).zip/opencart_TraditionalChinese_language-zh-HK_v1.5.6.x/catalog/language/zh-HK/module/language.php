<?php
// Text
$_['text_language'] = '語言';
?>