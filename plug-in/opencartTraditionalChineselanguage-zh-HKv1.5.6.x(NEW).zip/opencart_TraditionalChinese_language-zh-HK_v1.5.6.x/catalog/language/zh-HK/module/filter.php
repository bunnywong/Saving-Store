<?php
// Heading
$_['heading_title'] = '分類搜索';
?>