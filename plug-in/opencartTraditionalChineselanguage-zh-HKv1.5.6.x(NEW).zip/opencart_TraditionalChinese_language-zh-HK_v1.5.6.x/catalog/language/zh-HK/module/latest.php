<?php
// Heading
$_['heading_title']  = '最新商品';

// Text
$_['text_reviews']     = '5 星內取得 %s 星！';
?>