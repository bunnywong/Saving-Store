<?php
// Heading 
$_['heading_title']    = '插件管理';

// Text
$_['text_success']     = '成功：你已經安裝了你的插件！';

// Error
$_['error_permission'] = '警告：您沒有權限修改這個插件！';
$_['error_upload']     = '請先上傳！';
$_['error_filetype']   = '不存在的文件類型！';
?>