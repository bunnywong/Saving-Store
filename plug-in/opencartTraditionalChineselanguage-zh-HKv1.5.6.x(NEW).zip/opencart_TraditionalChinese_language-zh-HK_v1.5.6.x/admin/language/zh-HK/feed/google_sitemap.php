<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text 
$_['text_feed']        = '插件擴展';
$_['text_success']     = '成功： 您已變更Google Sitemap資料！';

// Entry
$_['entry_status']     = '狀態：';
$_['entry_data_feed']  = '資料數據網址：';

// Error
$_['error_permission'] = '警告： 您沒有權限修改Google Sitemap相應支付資料！';
?>