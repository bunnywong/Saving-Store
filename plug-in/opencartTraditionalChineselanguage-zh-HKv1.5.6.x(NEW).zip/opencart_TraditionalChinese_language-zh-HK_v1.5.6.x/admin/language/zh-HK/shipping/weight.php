<?php
// Heading
$_['heading_title']    = '按重量配送';

// Text
$_['text_shipping']    = '配送管理';
$_['text_success']     = '成功：按重量配送設定更新完成！';

// Entry
$_['entry_rate']       = '費用：<br /><span class="help">例如：5：10.00，7：12.00 重量：成本，重量：成本，等等。</span>';
$_['entry_tax_class']  = '稅類：';
$_['entry_geo_zone']   = '區域群組：';
$_['entry_status']     = '狀態：';
$_['entry_sort_order'] = '排序：';

// Error
$_['error_permission'] = '警告：您沒有變更按重量配送設定的權限！';
?>