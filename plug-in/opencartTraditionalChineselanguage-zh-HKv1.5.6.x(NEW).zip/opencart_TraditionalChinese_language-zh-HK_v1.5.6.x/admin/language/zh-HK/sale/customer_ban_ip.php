<?php
// Heading
$_['heading_title']    = '禁止客戶 IP';

// Text
$_['text_success']     = '成功：您已經修改了客戶的禁止IP！';

// Column
$_['column_ip']        = 'IP';
$_['column_customer']  = '客戶';
$_['column_action']    = '管理';

// Entry
$_['entry_ip']         = 'IP:';

// Error
$_['error_permission'] = '警告：您沒有修改該模塊的權限！';
$_['error_ip']         = 'IP 必須在1 至 15 個字符之間！';
?>