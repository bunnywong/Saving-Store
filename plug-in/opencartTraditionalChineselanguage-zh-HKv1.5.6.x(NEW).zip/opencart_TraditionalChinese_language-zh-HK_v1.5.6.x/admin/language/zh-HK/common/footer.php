<?php
// Text
$_['text_footer'] = '켊喧㖠<a href="http://www.opencart.cn">OpenCart֐΄֧㖍輯a><br />Version %s';
?>