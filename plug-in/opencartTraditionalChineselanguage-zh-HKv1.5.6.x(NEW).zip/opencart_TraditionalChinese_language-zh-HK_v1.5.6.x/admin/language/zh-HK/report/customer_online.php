<?php
// Heading
$_['heading_title']     = '網上客戶統計';

// Text 
$_['text_guest']        = '遊客';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = '顧客';
$_['column_url']        = '最近訪問的頁面';
$_['column_referer']    = '參考來源';
$_['column_date_added'] = '最後點擊日誌';
$_['column_action']     = '管理';
?>