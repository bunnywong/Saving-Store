<?php
// Text
$_['text_subject']       = '%s - 退換  %s 更新';
$_['text_return_id']     = '退換 ID：';
$_['text_date_added']    = '退換的日期：';
$_['text_return_status'] = '您的退換已更新到以下狀態：';
$_['text_comment']       = '您退換的意見：';
$_['text_footer']        = '如果您有任何問題請回復這個電子郵件。';
?>