<?php
// Heading
$_['heading_title']    = '小計';

// Text
$_['text_total']       = '訂單總計';
$_['text_success']     = '成功： 小計更新完成！';

// Entry
$_['entry_status']     = '狀態：';
$_['entry_sort_order'] = '排序：';

// Error
$_['error_permission'] = '警告： 您沒有變更小計的權限！';
?>
