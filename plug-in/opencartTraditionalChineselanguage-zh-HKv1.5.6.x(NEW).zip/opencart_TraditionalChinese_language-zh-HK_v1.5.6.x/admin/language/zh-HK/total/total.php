<?php
// Heading
$_['heading_title']    = '訂單配置';

// Text
$_['text_total']       = '訂單配置';
$_['text_success']     = '成功： 訂單配置更新完成！';

// Entry
$_['entry_status']     = '狀態：';
$_['entry_sort_order'] = '排序：';

// Error
$_['error_permission'] = '警告： 您沒有變更訂單配置的權限！';
?>
