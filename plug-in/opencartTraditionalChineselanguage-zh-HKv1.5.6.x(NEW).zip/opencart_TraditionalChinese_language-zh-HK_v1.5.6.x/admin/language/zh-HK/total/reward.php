<?php
// Heading
$_['heading_title']    = '獎勵積分';

// Text
$_['text_total']       = '訂單金額';
$_['text_success']     = '成功： 您已成功修改積分！';

// Entry
$_['entry_status']     = '狀態：';
$_['entry_sort_order'] = '排序：';

// Error
$_['error_permission'] = '警告： 您沒有變更積分的權限！';
?>