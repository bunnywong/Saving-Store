<?php
$_['text_rewardpoints_newsletter_bonus']   = 'Newsletter Sign-Up Bonus';
$_['text_rewardpoints_registration_bonus'] = 'Account Sign-Up Bonus';
$_['text_rewardpoints_review_bonus']       = 'Product Review Submission Bonus';
$_['text_rewardpoints_firstorder_bonus']   = 'First Order Bonus';
$_['text_rewardpoints_product_purchase']   = 'Order ID #%s - Purchase: %s';
?>