<?php
/**
 * Created by PhpStorm.
 * User: ANH To
 * Date: 10/7/14
 * Time: 11:11 PM
 */

class ModelRewardPointsTransactions extends Model
{
	public function logTransactionAfterConfirmOrder($order_id)
	{

	}
}