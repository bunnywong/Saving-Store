<?php
/**
 * Created by PhpStorm.
 * User: ANH To
 * Date: 12/27/14
 * Time: 9:22 AM
 */

class ModelRewardPointsValidation extends Model{

}