<?php
/**
 * Created by PhpStorm.
 * User: ANH To
 * Date: 10/10/14
 * Time: 3:58 PM
 */

class ModelRewardPointsObserver extends Model
{
	CONST BEHAVIOR_SIGN_UP          = 1;
	CONST BEHAVIOR_POSTING_REVIEW   = 2;
	CONST BEHAVIOR_REFERRAL_VISITOR = 3;
	CONST BEHAVIOR_REFERRAL_SIGN_UP = 4;
	CONST BEHAVIOR_NEWSLETTER       = 5;
	CONST BEHAVIOR_FACEBOOK_LIKE    = 6;
	CONST BEHAVIOR_FACEBOOK_SHARE   = 7;
	CONST BEHAVIOR_BIRTHDAY         = 8;

	CONST TRANSACTION_USE_POINTS_ON_ORDER = 11;
	CONST TRANSACTION_REWARD_ON_ORDER     = 12;
	public function afterAddCustomer($customer_id, $customer_data = array())
	{
		/** Earn reward points after sign-up */
		$behavior_query = $this->db->query("SELECT reward_point FROM ".DB_PREFIX."behavior_rules WHERE actions = ".self::BEHAVIOR_SIGN_UP. " AND status = 1");
		if(isset($behavior_query->row['reward_point']))
		{
			$this->language->load('rewardpoints/index');
			$reward_point   = $behavior_query->row['reward_point'];

			$log_message    = $this->language->get('behavior_sign_up');
			$this->db->query("INSERT INTO " . DB_PREFIX . "customer_reward SET
						  order_id = 0, order_status_id = 0,
						  customer_id = '" . (int)$customer_id . "',
						  description = '" . $this->db->escape($log_message) ."',
						  transaction_type = '" . (int)self::BEHAVIOR_SIGN_UP . "',
						  points = '" . (float)$reward_point . "',
						  status = '1',
						  date_added = NOW()");
		}
		$this->afterSubscribeNewsletter($customer_id, $customer_data);
		
	}

	public function afterSubscribeNewsletter($customer_id, $data)
	{
		if(isset($data['newsletter']) && $data['newsletter'] == 1)
		{
			$customer_reward_query = $this->db->query("SELECT customer_reward_id FROM ".DB_PREFIX."customer_reward WHERE customer_id = $customer_id AND transaction_type = ".self::BEHAVIOR_NEWSLETTER);
			if(isset($customer_reward_query->row['customer_reward_id']))
			{
				return false;
			}
			$this->language->load('rewardpoints/index');
			/** Earn reward points after subscribe newsletter  */
			$behavior_query = $this->db->query("SELECT reward_point FROM ".DB_PREFIX."behavior_rules WHERE actions = ".self::BEHAVIOR_NEWSLETTER. " AND status = 1");

			if(isset($behavior_query->row['reward_point']))
			{
				$this->language->load('rewardpoints/index');
				$reward_point   = $behavior_query->row['reward_point'];

				$log_message    = $this->language->get('behavior_newsletter');
				$this->db->query("INSERT INTO " . DB_PREFIX . "customer_reward SET
						  order_id = 0, order_status_id = 0,
						  customer_id = '" . (int)$customer_id . "',
						  transaction_type = '" . (int)self::BEHAVIOR_NEWSLETTER . "',
						  description = '" . $this->db->escape($log_message) ."',
						  points = '" . (float)$reward_point . "',
						  status = '1',
						  date_added = NOW()");
			}
		}
	}

    public function afterPlaceOrder($order_id)
    {
        $this->language->load('rewardpoints/index');
        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($order_id);

        $redeemed_order_query   = $this->db->query("SELECT * FROM ".DB_PREFIX."customer_reward WHERE order_id = $order_id AND transaction_type = ".self::TRANSACTION_USE_POINTS_ON_ORDER);
        $rewarded_order_query   = $this->db->query("SELECT * FROM ".DB_PREFIX."customer_reward WHERE order_id = $order_id AND transaction_type = ".self::TRANSACTION_REWARD_ON_ORDER);

        /** Update points used to checkout of customer */
        if(!isset($redeemed_order_query->row['customer_reward_id'])){
            if(isset($this->session->data['points_to_checkout']) && (int)$this->session->data['points_to_checkout'] > 0)
            {
                $points = (float)$this->session->data['points_to_checkout'];
                $log_message = "Order ID: <b>$order_id</b>, Redeemed -$points ".$this->config->get('text_points_'.$this->language->get('code'));
                $this->db->query("INSERT INTO " . DB_PREFIX . "customer_reward SET
							  order_id = $order_id,
							  customer_id = '" . (int)$this->customer->getId() . "',
							  description = '" . $this->db->escape($log_message) ."',
							  points = '" . (float)-$points . "',
							  transaction_type = '" . (int)self::TRANSACTION_USE_POINTS_ON_ORDER . "',
							  status = 1,
							  date_added = NOW()");
            }
        }

        /** Make reward points to customer in status Pending (Catalog Earning Rules, Shopping Earning Cart Rules)*/
        if(!isset($rewarded_order_query->row['customer_reward_id']))
        {
            if(isset($this->session->data['html_awarded']) && !empty($this->session->data['html_awarded']))
            {
                $status_reward = 0;
                $log_message = $this->language->get('text_reward_for_checkout')." #$order_id"."<br />".
                    "<ul class='order-rules-rewarded'>
						   ".$this->session->data['html_awarded']."
						   </ul>";
                if ($this->config->get('config_complete_status_id') == $order_info['order_status_id']) {
                    $status_reward = 1;
                }
                $this->db->query("INSERT INTO " . DB_PREFIX . "customer_reward SET
						  order_id = $order_id,
						  order_status_id = ".(int)$this->config->get('config_order_status_id').",
						  customer_id = '" . (int)$this->customer->getId() . "',
						  description = '" . $this->db->escape($log_message) ."',
						  points = '" . (float)$this->session->data['total_reward_points'] . "',
						  transaction_type = '" . (int)self::TRANSACTION_REWARD_ON_ORDER . "',
						  status = $status_reward,
						  date_added = NOW()");
            }
        }
    }
}