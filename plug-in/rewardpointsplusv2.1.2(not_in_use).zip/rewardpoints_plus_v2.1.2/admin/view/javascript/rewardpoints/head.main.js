/**
 * Created by ANH To on 9/30/14.
 */
window.RewardPoints = {
    Models: {},
    Collections: {},
    Views: {}
};
_.extend(window.RewardPoints, Backbone.Events);

