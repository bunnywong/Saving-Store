<?php
/**
 * User: Anh TO
 * Date: 10/3/14
 * Time: 10:51 AM
 */

class ModelCatalogRule extends Model
{
	CONST FIXED_REWARD = 1;
	CONST SPENT_REWARD = 2;
	public function applyRule($conditions, $rule_id){
		$counters = array();
		$_conditions = array();
		$data_filter = array();
		foreach($conditions as $counter => $rule)
		{
			if((int)strpos($counter, "-") == 0 )
			{
				$counters[$counter] = $rule;
			}
			else
			{
				$sub_counter = explode("--", $counter);

				$data_option = $this->getDataOption($rule['type'], false, $rule['value']);
				$_conditions[$counter]['data'] = $data_option;
				$_conditions[$counter]['data']['filter']['operator'] = $rule['operator'];

				$data_filter[$sub_counter[0]][$sub_counter[1]] = $_conditions[$counter]['data']['filter'];
			}
		}

		$rule_data = $this->getRule($rule_id);

		$sql = "DELETE FROM ".DB_PREFIX."product_to_reward WHERE rule_id = $rule_id";
		$this->db->query($sql);

        $use_default_reward = true;
        $default_reward = 0;
        $this->load->model('catalog/product');

		foreach ($counters as $counter => $condition)
		{
			$conds = (isset($data_filter[$counter])) ? $data_filter[$counter] : array();

			$products = $this->conditionToSql($conds, $condition);

			foreach ($products as $product)
			{
				if($rule_data['actions'] == self::FIXED_REWARD)
				{
					$reward_point = $rule_data['reward_point'];
				}
				else if($rule_data['actions'] == self::SPENT_REWARD)
				{
					$reward_point = round($product['price'] * $rule_data['reward_point'] / $rule_data['reward_per_spent']);
				}
                if($use_default_reward){
                    $product_reward = $this->model_catalog_product->getProductRewards($product['product_id']);
                    $customer_group = unserialize($rule_data['customer_group_ids']);
                    foreach($customer_group as $group_id){
                        if(isset($product_reward[$group_id])){
                            $default_reward = $product_reward[$group_id]['points'];
                        }
                    }
                }
                $reward_point += $default_reward;

				$sql = "INSERT INTO ".DB_PREFIX."product_to_reward VALUES(".$product['product_id'].", $rule_id, $reward_point);";

				$this->db->query($sql);
			}
		}
	}

	public function getRule($rule_id){
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "catalog_rules WHERE rule_id = " . (int)$rule_id);

		return $query->row;
	}
	/**
	 * $aggregator = all -> AND, = any -> OR
	 * $value: true/false
	 */
	protected function conditionToSql($data, $condition)
	{
		$field_available = array();
		$combine_conditions = array();
		if(count($data) > 0)
			foreach ($data as $condition)
			{
				foreach ($condition as $key => $value)
				{
					if($key != 'operator' && !in_array($key, $field_available))
					{
						$field_available[] = $key;
					}
				}
			}

		$products = $this->getProducts($data, $field_available);

		return $products;
	}

	protected function getDataOption($model_value = "", $json_output = true, $value_selected = '')
	{
		$model_value = (empty($model_value)) ? $this->request->post['value'] : $model_value;
		if($model_value != '')
		{
			if(strpos($model_value, "|") > -1 && strpos($model_value, "-") > -1)
			{
				$data   = explode("|", $model_value);
				$model  = $data[0];
				$data   = explode("-", $data[1]);
				$field  = $data[0];
				$type   = $data[1];
				$method = isset($data[2]) ? $data[2] : null;
			}else{
				$data = explode("|", $model_value);
				$model = $data[0];
				$id = $data[1];
			}

			$this->load->model($model);
			$model_alias = str_replace("/", "_", $model);
			$selected = "";
			$selected_ID = "";
			switch($model_alias)
			{
				case 'catalog_option':
					$option  = $this->{"model_".$model_alias}->getOption($id);
					$_data = $this->{"model_".$model_alias}->getOptionValues($id);

					$option_values = array();

					foreach($_data as $_option)
					{
						if($_option['option_value_id'] == $value_selected)
						{
							$selected_ID = $value_selected;
							break;
						}
					}
					$data = array(
						'type'  =>  $option['type'],
						'selected_ID'   => $selected_ID,
					);

					break;
				case 'catalog_manufacturer':
					$manufacturers = $this->{"model_".$model_alias}->{$method}(array());

					$option_values = array();
					foreach($manufacturers as $manufacturer)
					{
						if($manufacturer['manufacturer_id'] == $value_selected)
						{
							$selected_ID = $value_selected;
							break;
						}
					}

					$data = array(
						'type'  =>  'select',
						'selected_ID'   => $selected_ID,
						'filter'    =>  array(
							'filter_manufacturer_id'    =>  $selected_ID,
						)
					);

					break;
				case 'catalog_attribute':
					$this->load->model('catalog/attribute_group');
					$data = array(
						'filter_attribute_group_id' =>  $id
					);
					$_attribute = $this->{"model_".$model_alias."_group"}->getAttributeGroupDescriptions($id);

					$_attributes = $this->{"model_".$model_alias}->getAttributesByAttributeGroupId($data);

					$option_values = array();
					foreach($_attributes as $attribute)
					{
						if($attribute['attribute_id'] == $value_selected)
						{
							$selected_ID = $value_selected;
						}
					}

					$data = array(
						'type'  =>  'select',
						'selected_ID'   => $selected_ID,
						'filter'    =>  array(
							'filter_attribute_id'    =>  $selected_ID,
						)
					);

					break;
				case 'catalog_category':
					$categories = $this->{"model_".$model_alias}->{$method}(array());

					$option_values = array();
					foreach($categories as $category)
					{
						if($category['category_id'] == $value_selected)
						{
							$selected_ID = $value_selected;
						}
					}

					$data = array(
						'type'  =>  'select',
						'selected_ID'   => $selected_ID,
						'filter'    =>  array(
							'filter_category_id'    =>  $selected_ID,
						)
					);

					break;
				case 'catalog_product':

					$data = array(
						'type'  =>  'text',
						'selected'  =>  $value_selected,
						'filter'    =>  array(
							'filter_'.$field    =>  $value_selected,
						)
					);

					break;
			}

			if($json_output)
			{
				echo json_encode($data);
			}
			else
			{
				return $data;
			}
		}
	}

	public function getProducts($data = array(), $field_available = array())
	{
		$sql = "SELECT * FROM " . DB_PREFIX . "product p
                LEFT JOIN " . DB_PREFIX . "product_description pd ON (p.product_id = pd.product_id)";

		if (in_array('filter_category_id', $field_available))
		{
			$sql .= " LEFT JOIN " . DB_PREFIX . "product_to_category p2c ON (p.product_id = p2c.product_id)";
		}

		if (in_array('filter_attribute_id', $field_available))
		{
			$sql .= " LEFT JOIN " . DB_PREFIX . "product_attribute pat ON (p.product_id = pat.product_id)";
		}

		$sql .= " WHERE pd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		foreach($data as $condition)
		{
			if (isset($condition['filter_model']) && !empty($condition['filter_model']))
			{
				$sql .= " AND ".$this->operatorToMysql('p.`model`', $condition['operator'], $this->db->escape($condition['filter_model']));
			}

			if (isset($condition['filter_price']) && !empty($condition['filter_price']))
			{
				$sql .= " AND ".$this->operatorToMysql('p.`price`', $condition['operator'], $this->db->escape($condition['filter_price']));
			}

			if (isset($condition['filter_sku']) && !empty($condition['filter_sku']))
			{
				$sql .= " AND ".$this->operatorToMysql('p.`sku`', $condition['operator'], $this->db->escape($condition['filter_sku']));
			}

			if (isset($condition['filter_manufacturer_id']) && !empty($condition['filter_manufacturer_id']))
			{
				$sql .= " AND ".$this->operatorToMysql('p.`manufacturer_id`', $condition['operator'], $this->db->escape($condition['filter_manufacturer_id']));
			}

			if (isset($condition['filter_category_id']) && !empty($condition['filter_category_id']))
			{
				$sql .= " AND ".$this->operatorToMysql('p2c.`category_id`', $condition['operator'], $this->db->escape($condition['filter_category_id']));
			}

			if (isset($condition['filter_attribute_id']) && !empty($condition['filter_attribute_id']))
			{
				$sql .= " AND ".$this->operatorToMysql('pat.`attribute_id`', $condition['operator'], $this->db->escape($condition['filter_attribute_id']));
			}
		}

		$sql .= " GROUP BY p.product_id";
		$sql .= " ORDER BY p.product_id";
		$sql .= " DESC";

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	protected function operatorToMysql($field, $op, $value)
	{
		$op = htmlspecialchars_decode($op);
		$text = '';
		switch($op)
		{
			case '>=':
				$text = $field ." $op '". $value."'";
				break;
			case '<=':
				$text = $field ." $op '". $value."'";
				break;
			case '>':
				$text = $field ." $op '". $value."'";
				break;
			case '<':
				$text = $field ." $op '". $value."'";
				break;
			case '{}':
				$text = $field ." LIKE '%". $value."%'";
				break;
			case '!{}':
				$text = $field ." NOT LIKE '%". $value."%'";
				break;
			case '()':
				$text = $field ." IN ('$value')";
				break;
			case '==':
				$text = $field ." = '$value'";
				break;
			case '!()':
				$text = $field ." NOT IN ('$value')";
				break;
			case '=!':
				$text = $field ." <> '$value'";
				break;
		}
		return $text." ";
	}
}